int main() {
    int x = "Hello";  // Eroare de tip: se încearcă asignarea unui șir de caractere unei variabile de tip int
    return 0;
}

