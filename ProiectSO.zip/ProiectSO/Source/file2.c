#include <stdio.h>

int main() {
    printf("Hello from file2.c\n");
    return 0;
}

