#include <stdio.h>

int main() {
    printf("Hello from file1.c\n");
    return 0;
}

